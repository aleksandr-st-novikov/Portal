﻿using EJ.DAL.Models.Rbac;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EJ.DAL.Util
{
    public class AreaOperation
    {
        protected AreaOperationsEnum areaEnum;

        public string Name { get; private set; }
        public string Description { get; private set; }

        public AreaOperation(AreaOperationsEnum areaEnum, string name, string description)
        {
            this.areaEnum = areaEnum;
            Name = name;
            Description = description;
        }

        public Operation ToPermission()
        {
            return new Operation() { Area = areaEnum.AreaName, Name = areaEnum.AreaPrefix + Name, Description = Description };
        }

        public override string ToString()
        {
            return areaEnum.AreaPrefix + Name;
        }
    }

    public abstract class AreaOperationsEnum
    {
        public string AreaName { get; protected set; }
        public string AreaPrefix { get; protected set; }
    }
}
