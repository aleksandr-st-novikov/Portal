﻿using EJ.DAL.Models;
using EJ.DAL.Models.Rbac;
using System;
using System.Data.Entity;
using System.Linq;
using System.Collections.Generic;
using EJ.DAL.Chkp.Models;
using EJ.DAL.Dashboard;


namespace EJ.DAL
{
    public class EJContext : DbContext
    {
        public DbSet<Employee> Employees { get; set; }
        public DbSet<ContactInfo> Contacts { get; set; }
        public DbSet<Department> Departments { get; set; }

        public DbSet<Announcing> Announcements { get; set; }

        public DbSet<User> Users { get; set; }
        public DbSet<Role> RbacRoles { get; set; }
        public DbSet<Operation> RbacOperations { get; set; }

        public DbSet<Permit> ChkpPermits { get; set; }
        public DbSet<PermitSubject> ChkpPermitSubjects { get; set; }
        public DbSet<PermitLog> ChkpPermitLog { get; set; }

        public EJContext() : base("EJContext")
        {
            Database.SetInitializer<EJContext>(new EJInitializer());
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            // department parent
            modelBuilder.Entity<Department>()
                .HasMany(e => e.Departments)
                .WithOptional(e => e.Parent)
                .HasForeignKey(e => e.ParentID);
            
            // department employee
            modelBuilder.Entity<Department>()
                .HasMany(e => e.Employees)
                .WithOptional(e => e.Department)
                .HasForeignKey(e => e.DepartmentID);

            // employee contact info
            modelBuilder.Entity<ContactInfo>()
                .HasRequired(e => e.Employee)
                .WithOptional(st => st.Contact)
                .WillCascadeOnDelete();
        }
   
        public IQueryable<Employee> GetEmploeesView()
        {
            return Employees.Where(s => s.Status == EmployeeStatus.Active).OrderBy(s => s.LastName).ThenBy(s => s.FirstName);
        }

        public Employee GetEmployeeByFullName(string fullName)
        {
            string[] parts = fullName.Split(new [] {" "}, StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length > 2)
            {
                string last = parts[0];
                string first = parts[1];
                string patr = parts[2];
                return Employees.FirstOrDefault(s => s.LastName == last && s.FirstName == first && s.PatrName == patr);
            }
            else if (parts.Length > 1)
            {
                string last = parts[0];
                string first = parts[1];
                return Employees.FirstOrDefault(s => s.LastName == last && s.FirstName == first);
            }
            else
            {
                return null;
            }
        }

        public IEnumerable<Department> GetChildDepartments(int? parentId, bool itself = false)
        {
            var result = new List<Department>();
            var deps = Departments.ToList();
            
            var parent = deps.FirstOrDefault(d => d.DepartmentID == parentId);
            if (parent == null) 
            {
                return result;
            }

            if (itself)
            {
                result.Add(parent);
            }
            
            var children = deps.Where(d => d.ParentID == parentId);
            while (children.Count() > 0)
            {
                result.AddRange(children);
                var parents = new HashSet<int>(children.Select(d => d.DepartmentID));
                children = deps.Where(d => d.ParentID.HasValue && parents.Contains((int)d.ParentID));
            }

            return result;
        }

        public int[] GetChildDepartmentsID(int? parentId, bool itself = false)
        {
            return GetChildDepartments(parentId, itself).Select(d => d.DepartmentID).ToArray();
        }
    }
}