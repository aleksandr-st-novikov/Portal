﻿using EJ.DAL.Models;
using EJ.DAL.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity;
using System.Text;
using System.Threading.Tasks;

namespace EJ.DAL.Dashboard
{
    public sealed class DashboardOperations : AreaOperationsEnum
    {
        public static AreaOperation EditAnns { get; private set; }
        public static AreaOperation EditAllAnns { get; private set; }
        public static AreaOperation Administer { get; private set; }

        public static DashboardOperations Enum { get; private set; }

        static DashboardOperations()
        {
            var areaEnum = new DashboardOperations() { AreaName = "Доска объявлений", AreaPrefix = "dash" };

            EditAnns = new AreaOperation(areaEnum, "EditAnns", "Редактирование объявлений подчиненных отделов");
            EditAllAnns = new AreaOperation(areaEnum, "EditAllAnns", "Редактирование объявлений всех отделов");
            Administer = new AreaOperation(areaEnum, "Administer", "Администрирование");
        }
    }

    public class DashboardRepository
    {
        private EJContext ctx;

        public DashboardRepository(EJContext context)
        {
            if (context == null)
            {
                throw new ArgumentNullException("context");
            }
            ctx = context;
        }

        public IQueryable<Announcing> GetAnns()
        {
            return ctx.Announcements.Include(a => a.User).OrderByDescending(a => a.DatePublish);
        }

        public bool UserCanCreate(User user)
        {
            return user != null;
        }

        public bool UserCanEdit(User user, Announcing ann)
        {
            if (user == null)
            {
                return false;
            }
            var deps = ctx.GetChildDepartmentsID(user.Employee.DepartmentID, true);
            return user.Can(DashboardOperations.Administer) || user.Can(DashboardOperations.EditAllAnns) ||
                (user.Employee.IsHead && deps.Contains((int)ann.User.Employee.DepartmentID));
        }

        public static void Seed(EJContext ctx)
        {
            // permissions
            ctx.RbacOperations.Add(DashboardOperations.EditAllAnns.ToPermission());
            ctx.RbacOperations.Add(DashboardOperations.Administer.ToPermission());
        }
    }
}
