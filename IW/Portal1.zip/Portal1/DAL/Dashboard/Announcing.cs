﻿using EJ.DAL.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EJ.DAL.Dashboard
{
    [Table("Announcements")]
    public class Announcing
    {
        public int ID { get; set; }
        
        public int UserID { get; set; }

        public DateTime DatePublish { get; set; }

        public DateTime? DateEdit { get; set; }

        public int? UserEditID { get; set; }
        
        [Display(Name = "Заголовок")]
        [StringLength(120)]
        public string Title { get; set; }

        [Display(Name = "Текст объявления")]
        [DataType(DataType.MultilineText)]
        public string Message { get; set; }

        public virtual User User { get; set; }

        public virtual User UserEdit { get; set; }
    }
}
