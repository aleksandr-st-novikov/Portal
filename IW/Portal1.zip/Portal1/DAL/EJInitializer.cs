﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using EJ.DAL.Models;
using EJ.DAL.Models.Rbac;

namespace EJ.DAL
{
    public class EJInitializer : DropCreateDatabaseIfModelChanges<EJContext>
    {
        protected override void Seed(EJContext ctx)
        {
            EJ.DAL.Chkp.ChkpRepository.Seed(ctx);
            EJ.DAL.Dashboard.DashboardRepository.Seed(ctx);
        }
    }
}