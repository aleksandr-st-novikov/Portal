﻿using EJ.DAL.Chkp.Models;
using EJ.DAL.Models;
using EJ.DAL.Models.Rbac;
using EJ.DAL.Util;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EJ.DAL.Chkp
{
    public sealed class ChkpOperations : AreaOperationsEnum
    {
        public static AreaOperation ViewEvents { get; private set; }
        public static AreaOperation ViewAllEvents { get; private set; }
        public static AreaOperation EditEvents { get; private set; }
        public static AreaOperation EditAllEvents { get; private set; }
        public static AreaOperation ControlEvents { get; private set; }
        public static AreaOperation Administer { get; private set; }

        public static ChkpOperations Enum { get; private set; }

        static ChkpOperations()
        {
            var areaEnum = new ChkpOperations() { AreaName = "Электронный журнал", AreaPrefix = "chkp" };

            ViewEvents      = new AreaOperation(areaEnum, "ViewEvents", "Просмотр записей подчиненных отделов");
            ViewAllEvents   = new AreaOperation(areaEnum, "ViewAllEvents", "Просмотр записей всех отделов");
            EditEvents      = new AreaOperation(areaEnum, "EditEvents", "Редактирование записей подчиненных отделов");
            EditAllEvents   = new AreaOperation(areaEnum, "EditAllEvents", "Редактирование записей всех отделов");
            ControlEvents   = new AreaOperation(areaEnum, "ControlEvents", "Фиксирование времени событий");
            Administer      = new AreaOperation(areaEnum, "Administer", "Администрирование");
        }
    }

    public class ChkpRepository
    {
        private EJContext ctx;

        public ChkpRepository(EJContext context)
        {
            if (context == null)
            {
                throw new ArgumentNullException("context");
            }
            ctx = context;
        }

        public IQueryable<Permit> GetPermits(PermitsFilter filter)
        {
            if (filter == null)
            {
                throw new ArgumentNullException("filter");
            }

            var list = ctx.ChkpPermits
                .OrderByDescending(p => p.Start)
                .Include(p => p.Author)
                .Include(p => p.Employee)
                .Include(p => p.Subject);

            // filter
            
            if (filter.Departments != null && filter.Departments.Length > 0)
            {
                list = list.Where(p => filter.Departments.Contains(p.DepartmentID));
            }
            if (filter.StartDate.HasValue)
            {
                list = list.Where(p => p.Start >= filter.StartDate || (p.Start <= filter.StartDate && p.End >= filter.StartDate));
            }
            if (filter.EndDate.HasValue)
            {
                list = list.Where(p => p.End <= filter.EndDate);
            }
            if (filter.HideClosed)
            {
                list = list.Where(p => p.EndReg == null);
            }
            if (!String.IsNullOrEmpty(filter.EmployeeName))
            {
                list = list.Where(s => s.Employee.LastName.ToUpper().StartsWith(filter.EmployeeName.ToUpper()));
            }

            if (!filter.ShowDeleted)
            {
                list = list.Where(p => p.IsDeleted == false);
            }

            return list;
        }

        public bool UserCanEdit(User user, Permit permit)
        {
            if (permit.IsClosed || permit.IsDeleted)
                return false;

            if (user.Can(ChkpOperations.EditAllEvents))
                return true;

            if (user.Can(ChkpOperations.EditEvents))
            {
                var deps = ctx.GetChildDepartments(user.Employee.DepartmentID, true).Select(d => d.DepartmentID).ToArray();
                return deps.Contains(permit.DepartmentID);
            }
            return false;
        }

        public bool UserCanControl(User user, Permit permit)
        {
            return user.Can(ChkpOperations.ControlEvents) && !(permit.IsClosed || permit.IsDeleted);
        }

        public bool UserCanDelete(User user, Permit permit)
        {
            return UserCanEdit(user, permit) && permit.StartReg == null;
        }

        public IQueryable<PermitLog> GetLog(Permit permit)
        {
            return ctx.ChkpPermitLog.OrderByDescending(l => l.Time).Where(l => l.PermitID == permit.ID);
        }

        private JObject GetChanges(Permit p, string[] fields)
        {
            var diffProps = new HashSet<string>(fields);
            var diff = new JObject();
            foreach (var prop in typeof(Permit).GetProperties(System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance))
            {
                if (prop.CanRead && diffProps.Contains(prop.Name) && ctx.Entry(p).Property(prop.Name).IsModified)
                {
                    object valold = ctx.Entry(p).OriginalValues[prop.Name];
                    object valnew = prop.GetValue(p);
                    if (valnew != valold)
                    {
                        diff.Add(prop.Name, new JValue(valold));
                    }
                }
            }
            return diff;
        }

        public PermitLog Log(Permit permit, string description, string userLogin, int employeeId)
        {
            var log = new PermitLog()
            {
                Time = DateTime.Now,
                PermitID = permit.ID,
                EmployeeID = employeeId,
                UserLogin = userLogin,
                Description = description
            };
            ctx.ChkpPermitLog.Add(log);
            return log;
        }

        public PermitLog LogChange(Permit permit, string description, string userLogin, int employeeId)
        {
            var diff = GetChanges(permit, new[] { "Type", "SubjectID", "Start", "End", "Comment", "CommentReg", "IsDeleted" });
            var log = new PermitLog()
            {
                Time = DateTime.Now,
                PermitID = permit.ID,
                EmployeeID = employeeId,
                UserLogin = userLogin,
                Description = description,
                Log = diff.ToString()
            };
            ctx.ChkpPermitLog.Add(log);
            return log;
        }

        public static void Seed(EJContext ctx)
        {
            // permissions
            ctx.RbacOperations.Add(ChkpOperations.ViewEvents.ToPermission());
            ctx.RbacOperations.Add(ChkpOperations.ViewAllEvents.ToPermission());
            ctx.RbacOperations.Add(ChkpOperations.EditEvents.ToPermission());
            ctx.RbacOperations.Add(ChkpOperations.EditAllEvents.ToPermission());
            ctx.RbacOperations.Add(ChkpOperations.ControlEvents.ToPermission());
            ctx.RbacOperations.Add(ChkpOperations.Administer.ToPermission());

            // permits subjects
            ctx.ChkpPermitSubjects.Add(new PermitSubject() { Title = "Изменения в графике", IsActive = true });
            ctx.ChkpPermitSubjects.Add(new PermitSubject() { Title = "Замена", IsActive = true });
            ctx.ChkpPermitSubjects.Add(new PermitSubject() { Title = "За ранее отработанное время", IsActive = true });
            ctx.ChkpPermitSubjects.Add(new PermitSubject() { Title = "В поликлинику", IsActive = true });
            ctx.ChkpPermitSubjects.Add(new PermitSubject() { Title = "По личным обстоятельствам", IsActive = true });
            ctx.ChkpPermitSubjects.Add(new PermitSubject() { Title = "По служебной необходимости", IsActive = true });
            ctx.ChkpPermitSubjects.Add(new PermitSubject() { Title = "Вызов с выходного", IsActive = true });
        }
    }
}
