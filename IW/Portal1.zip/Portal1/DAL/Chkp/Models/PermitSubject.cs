﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EJ.DAL.Chkp.Models
{
    public class PermitSubject
    {
        public int ID { get; set; }

        [Index(IsUnique = true), Required, StringLength(100)]
        [Display(Name = "Цель события")]
        public string Title { get; set; }

        [Display(Name = "Активно")]
        public bool IsActive { get; set; }
    }
}
