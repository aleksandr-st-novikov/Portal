﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EJ.DAL.Chkp.Models
{
    [Table("PermitLog")]
    public class PermitLog
    {
        public int ID { get; set; }

        public DateTime Time { get; set; }

        public int PermitID { get; set; }

        public int EmployeeID { get; set; }

        [StringLength(60)]
        public string UserLogin { get; set; }

        [StringLength(120)]
        public string Description { get; set; }

        public string Log { get; set; }
    }
}
