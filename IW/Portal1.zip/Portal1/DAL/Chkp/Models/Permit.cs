﻿using EJ.DAL.Models;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace EJ.DAL.Chkp.Models
{
    public enum PermitType
    {
        [Description("Посещение предприятия")]
        Visit,

        [Description("Выход в рабочее время")]
        Leaving
    }

    public class Permit
    {
        public int ID { get; set; }

        [Display(Name = "Подразделение")]
        public int DepartmentID { get; set; }

        [Display(Name = "Руководитель")]
        public int? HeadID { get; set; }

        [Display(Name = "Сотрудник")]
        public int? EmployeeID { get; set; }

        [Display(Name = "Автор согласования")]
        public int AuthorID { get; set; }

        [Display(Name = "Дата создания"), DataType(DataType.DateTime)]
        public DateTime CreateDate { get; set; }

        [Display(Name = "Тип события")]
        public PermitType Type { get; set; }

        [Display(Name = "Цель события")]
        public int SubjectID { get; set; }

        [Display(Name = "Начало"), DataType(DataType.DateTime)]
        public DateTime Start { get; set; }

        [Display(Name = "Начало зарегестрировано"), DataType(DataType.DateTime)]
        public DateTime? StartReg { get; set; }

        [Display(Name = "Конец"), DataType(DataType.DateTime)]
        public DateTime End { get; set; }

        [Display(Name = "Конец зарегестрирован"), DataType(DataType.DateTime)]
        public DateTime? EndReg { get; set; }

        [Display(Name = "Запись удалена")]
        public bool IsDeleted { get; set; }

        [StringLength(200), Display(Name = "Примечание")]
        public string Comment { get; set; }

        [StringLength(200), Display(Name = "Примечание регистрации")]
        [DataType(DataType.MultilineText)]
        public string CommentReg { get; set; }

        public bool IsClosed { get { return StartReg != null && EndReg != null; } }

        public virtual Department Department { get; set; }
        public virtual Employee Head { get; set; }
        public virtual Employee Employee { get; set; }
        public virtual User Author { get; set; }
        public virtual PermitSubject Subject { get; set; }
    }
}
