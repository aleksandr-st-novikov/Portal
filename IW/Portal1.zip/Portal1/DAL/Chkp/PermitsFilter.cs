﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EJ.DAL.Chkp
{
    public class PermitsFilter
    {
        public DateTime? StartDate { get; set; }

        public DateTime? EndDate { get; set; }

        public int[] Departments { get; set; }

        public string EmployeeName { get; set; }

        public bool HideClosed { get; set; }

        public bool ShowDeleted { get; set; }

        public bool IsEmpty
        {
            get
            {
                return StartDate == null && EndDate == null && 
                    (Departments == null || Departments.Length == 0) &&
                    String.IsNullOrEmpty(EmployeeName);
            }
        }

        public PermitsFilter()
        {
            HideClosed = true;
        }
    }
}
