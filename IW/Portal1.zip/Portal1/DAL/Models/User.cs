﻿using EJ.DAL.Models.Rbac;
using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using EJ.DAL.Util;

namespace EJ.DAL.Models
{
    public class User
    {
        private HashSet<string> operations;

        public int ID { get; set; }

        [Index(IsUnique = true), Required, StringLength(60)]
        [Display(Name = "Логин")]
        public string Login { get; set; }

        [Display(Name = "Сотрудник")]
        public int? EmployeeID { get; set; }

        [Display(Name = "Активен")]
        public bool IsActive { get; set; }

        [Display(Name = "Зарегистрирован")]
        public DateTime? Registered { get; set; }

        [Display(Name = "Последний вход")]
        public DateTime? LastLogin { get; set; }

        public virtual Employee Employee { get; set; }
        public virtual ICollection<Role> Roles { get; set; }

        public User()
        {
            IsActive = true;
        }

        public HashSet<string> GetOperations()
        {
            if (operations == null)
            {
                operations = new HashSet<string>(Roles.SelectMany(r => r.Operations).Select(p => p.Name));
            }
            return operations;
        }
        
        public bool Can(AreaOperation operation)
        {
            return Can(operation.ToString());
        }

        public bool Can(string operationName)
        {
            GetOperations();
            return operations.Contains(operationName);
        }
    }
}
