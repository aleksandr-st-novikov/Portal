﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EJ.DAL.Models
{
    public enum EmployeeCategory
    {
        [Description("Рабочий")]
        Worker,
        [Description("Служащий")]
        Servant,
        [Description("Специалист")]
        Specialist,
        [Description("Руководитель")]
        Head
    }

    public enum EmployeeStatus 
    {
        [Description("Работает")]
        Active,
        [Description("Отстранен")]
        Retired
    }

    public class Employee
    {
        private string name = null;
        private string fullName = null;

        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int ID { get; set; }

        [Required, StringLength(80)]
        [Display(Name = "Фамилия")]
        public string LastName { get; set; }

        [Required, StringLength(80)]
        [Display(Name = "Имя")]
        public string FirstName { get; set; }

        [StringLength(80)]
        [Display(Name = "Отчество")]
        public string PatrName { get; set; }

        [NotMapped]
        [Display(Name = "Краткое имя")]
        public string Name
        {
            get
            {
                if (name == null)
                {
                    name = LastName + " " + FirstName;
                }
                return name;
            }
        }

        [NotMapped]
        [Display(Name = "Полное имя")]
        public string FullName
        {
            get
            {
                if (fullName == null)
                {
                    fullName = LastName + " " + FirstName + " " + PatrName;
                }
                return fullName;
            }
        }

        [StringLength(110)]
        [Display(Name = "Должность")]
        public string Position { get; set; }

        [Display(Name = "Подразделение")]
        public int? DepartmentID { get; set; }

        [Display(Name = "Категория сотрудника")]
        public EmployeeCategory Category { get; set; }

        public DateTime DateHire { get; set; }
        public DateTime? DateRetire { get; set; }
        public DateTime? DateBirth { get; set; }

        [Display(Name = "Состояние")]
        public EmployeeStatus Status { get; set; }

        public virtual Department Department { get; set; }
        public virtual ContactInfo Contact { get; set; }

        [Display(Name = "Глава подразделения")]
        [NotMapped]
        public bool IsHead
        {
            get { return Department != null && Department.HeadID == ID; }
        }
    }
}