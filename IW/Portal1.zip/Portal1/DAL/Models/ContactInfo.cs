﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EJ.DAL.Models
{
    [Table("ContactInfo")]
    public class ContactInfo
    {
        [Key]
        public int EmployeeID { get; set; }

        [StringLength(50)]
        public string PhoneInteroffice { get; set; }

        [StringLength(50)]
        public string PhoneLandline { get; set; }

        [StringLength(50)]
        public string PhoneMobile { get; set; }

        [StringLength(30)]
        public string Room { get; set; }

        public Employee Employee { get; set; }
    }
}
