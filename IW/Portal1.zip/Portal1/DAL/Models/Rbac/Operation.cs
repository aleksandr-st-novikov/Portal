﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EJ.DAL.Models.Rbac
{
    public class Operation
    {
        public int OperationID { get; set; }
        
        [Required, StringLength(50), Display(Name = "Модуль")]
        public string Area { get; set; }
        
        [Index(IsUnique = true), Required, StringLength(70), Display(Name = "Имя")]
        public string Name { get; set; }

        [Required, StringLength(70), Display(Name = "Описание")]
        public string Description { get; set; }

        public virtual ICollection<Role> Roles { get; set; }
    }
}
