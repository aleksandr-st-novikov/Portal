﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EJ.DAL.Models.Rbac
{
    public class Role
    {
        public int RoleID { get; set; }
        [Required, StringLength(100), Display(Name = "Название")]
        public string Name { get; set; }

        public virtual ICollection<Operation> Operations { get; set; }
        public virtual ICollection<User> Users { get; set; }
    }
}
