﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EJ.DAL.Models
{
    public class Department
    {
        public int DepartmentID { get; set; }

        [Index(IsUnique = true), Required, StringLength(150)]
        [Display(Name="Название")]
        public string Title { get; set; }

        [Display(Name="Родительское подразделение")]
        public int? ParentID { get; set; }

        [Display(Name="Руководитель")]
        public int? HeadID { get; set; }
        
        public virtual Department Parent { get; set; }
        public virtual Employee Head { get; set; }
        public virtual ICollection<Department> Departments { get; set; }
        public virtual ICollection<Employee> Employees { get; set; }
    }
}