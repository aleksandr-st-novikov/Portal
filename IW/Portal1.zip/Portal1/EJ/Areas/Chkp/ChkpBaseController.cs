﻿using EJ.DAL.Chkp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EJ.Areas.Chkp
{
    //[Authorize(Roles = "Доступ 1С Электронный журнал,Отдел информационных технологий")]
    public abstract class ChkpBaseController : BaseController 
    {
        protected ChkpRepository rep;

        public ChkpBaseController() : base()
        {
            rep = new ChkpRepository(db);
        }

        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            base.OnActionExecuting(filterContext);
            if (AppUser != null && AppUser.User == null)
            {
                filterContext.Result = new HttpUnauthorizedResult("Вы не зарегистрированы в системе для доступа к приложению");
                return;
            }

        }
    }
}