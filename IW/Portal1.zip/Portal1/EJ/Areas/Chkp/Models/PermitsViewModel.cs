﻿using EJ.Common;
using EJ.DAL;
using EJ.DAL.Chkp;
using EJ.DAL.Chkp.Models;
using EJ.DAL.Models;
using System;
using System.Collections.Generic;

namespace EJ.Areas.Chkp.Models
{
    public class PermitsViewFilter : PermitsFilter
    {
        public int? DepartmentID { get; set; }

        public bool Autoupdate { get; set; }

        public PermitsViewFilter()
        {
            Autoupdate = true;
        }
    }

    public class PermitsViewModel
    {
        public IEnumerable<Permit> List { get; set; }
        public PermitsViewFilter Filter { get; set; }
        public PagingInfo Paging { get; set; }
        public bool CanControl { get; set; }
        public bool CanAdminister { get; set; }
        public bool CanViewAll { get; set; }
        public bool CanEdit { get; set; }
    }
}