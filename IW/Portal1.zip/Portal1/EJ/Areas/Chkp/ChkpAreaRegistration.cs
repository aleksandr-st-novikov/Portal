﻿using System.Web.Mvc;

namespace EJ.Areas.Chkp
{
    public class ChkpAreaRegistration : AreaRegistration 
    {
        public override string AreaName 
        {
            get 
            {
                return "Chkp";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context) 
        {
            context.MapRoute(
                "Chkp_default",
                "Chkp/{controller}/{action}/{id}",
                new { controller = "Default", action = "Index", id = UrlParameter.Optional },
                new[] { "EJ.Areas.Chkp.Controllers" }
            );
        }
    }
}