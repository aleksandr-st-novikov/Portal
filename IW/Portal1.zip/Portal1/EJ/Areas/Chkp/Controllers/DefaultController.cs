﻿using EJ.Areas.Chkp.Models;
using EJ.DAL;
using EJ.DAL.Chkp;
using EJ.DAL.Chkp.Models;
using EJ.DAL.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web.Mvc;

namespace EJ.Areas.Chkp.Controllers
{
    public class DefaultController : ChkpBaseController
    {
        public ActionResult Index([Bind(Prefix = "Filter")] PermitsViewFilter filter)
        {
            if (!AppUser.User.Can(ChkpOperations.ViewEvents))
            {
                return new HttpUnauthorizedResult();
            }

            // filter

            filter = SetupFilter(filter);
            var model = new PermitsViewModel() { Filter = filter };

            List<Department> departments;
            if (AppUser.User.Can(ChkpOperations.ViewAllEvents))
            {
                departments = db.Departments.OrderBy(d => d.Title).ToList();
                ViewData["Filter.DepartmentID"] = DropDownListHelpers.DepartmentList(departments, filter.DepartmentID, null);
            }
            else
            {
                departments = db.GetChildDepartments(AppUser.User.Employee.DepartmentID, true).ToList();
                ViewData["Filter.DepartmentID"] = DropDownListHelpers.DepartmentList(departments, filter.DepartmentID, AppUser.User.Employee.DepartmentID, true);
            }

            // get permit list
            if (filter.DepartmentID.HasValue)
            {
                filter.Departments = new int[] { filter.DepartmentID.Value }; 
            }
            else
            {
                filter.Departments = departments.Select(d => d.DepartmentID).ToArray();
            }
            model.List = rep.GetPermits(filter).ToList();

            // permissions

            model.CanAdminister = AppUser.User.Can(ChkpOperations.Administer);
            model.CanEdit = AppUser.User.Can(ChkpOperations.EditEvents) || AppUser.User.Can(ChkpOperations.EditAllEvents);
            model.CanControl = AppUser.User.Can(ChkpOperations.ControlEvents);
            model.CanViewAll = AppUser.User.Can(ChkpOperations.ViewAllEvents);

            if (Request.IsAjaxRequest())
            {
                return View("Grid", model);
            }
            else
            {
                return View(model);
            }
        }

        private PermitsViewFilter SetupFilter(PermitsViewFilter filter)
        {
            if (Request.Params["clear"] != null)
            {
                Session["filter"] = null;
                filter = null;
                ModelState.Clear();
            }
            else if (filter != null)
            {
                Session["filter"] = filter;
            }
            else
            {
                filter = (PermitsViewFilter)Session["filter"];
            }

            if (filter == null)
            {
                filter = new PermitsViewFilter();
                filter.StartDate = DateTime.Today;
            }

            return filter;
        }

        public ActionResult ListEmploees(int id)
        {
            var dep = db.Departments.Find(id);
            if (dep == null)
            {
                return HttpNotFound();
            }
            var data = dep.Employees.OrderBy(e => e.LastName).ThenBy(e => e.FirstName).Select(e => new { ID = e.ID, Name = e.FullName }).ToList();
            return Json(data, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Create()
        {
            if (!AppUser.User.Can(ChkpOperations.EditEvents))
            {
                return new HttpUnauthorizedResult();
            }

            int employeeDep = AppUser.User.Employee.DepartmentID ?? 0;
            if (AppUser.User.Can(ChkpOperations.EditAllEvents))
            {
                ViewBag.DepartmentID = DropDownListHelpers.DepartmentList(db.Departments.OrderBy(d => d.Title).ToList(), null);
            }
            else
            {
                ViewBag.DepartmentID = DropDownListHelpers.DepartmentList(db.Departments.OrderBy(d => d.Title).ToList(), null, employeeDep, true);
            }            
            ViewBag.SubjectID = new SelectList(db.ChkpPermitSubjects.OrderBy(s => s.Title), "ID", "Title");

            var item = new Permit()
            {
                DepartmentID = employeeDep,
                Start = DateTime.Today,
                End = DateTime.Today
            };
            return View(item);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ID,DepartmentID,EmployeeID,Type,SubjectID,Start,End,Comment")] Permit model)
        {
            if (!AppUser.User.Can(ChkpOperations.EditEvents))
            {
                return new HttpUnauthorizedResult();
            }

            int emploeeDep = AppUser.User.Employee.DepartmentID ?? 0;

            if (ModelState.IsValid)
            {
                model.CreateDate = DateTime.Now;
                model.AuthorID = AppUser.User.ID;
                model.HeadID = db.Departments.Find(model.DepartmentID).HeadID;
                db.ChkpPermits.Add(model);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            
            if (!AppUser.User.Can(ChkpOperations.EditAllEvents))
            {
                ViewBag.DepartmentID = new SelectList(db.Departments.OrderBy(d => d.Title), "DepartmentID", "Title", model.DepartmentID);
            }
            else
            {
                ViewBag.DepartmentID = new SelectList(db.Departments.Where(d => d.DepartmentID == emploeeDep), "DepartmentID", "Title", model.DepartmentID);
            }
            ViewBag.SubjectID = new SelectList(db.ChkpPermitSubjects.OrderBy(s => s.Title), "ID", "Title", model.SubjectID);
            return View(model);
        }

        public ActionResult Details(int id)
        {
            var item = db.ChkpPermits.Find(id);
            if (item == null)
            {
                return HttpNotFound();
            }

            ViewBag.Log = rep.GetLog(item).ToList();

            ViewBag.CanEdit = rep.UserCanEdit(AppUser.User, item);
            ViewBag.CanDelete = rep.UserCanDelete(AppUser.User, item);
            ViewBag.CanControl = rep.UserCanControl(AppUser.User, item);
            
            return View(item);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Details(int id, [Bind(Include="CommentReg")] Permit model)
        {
            var item = db.ChkpPermits.Find(id);
            if (item == null || !rep.UserCanControl(AppUser.User, item))
            {
                return HttpNotFound();
            }

            if (item.StartReg == null)
            {
                item.StartReg = DateTime.Now;
            }
            else if (item.EndReg == null)
            {
                item.EndReg = DateTime.Now;
            }

            item.CommentReg = model.CommentReg;

            rep.LogChange(item, "Контроль служебного входа", AppUser.User.Login, AppUser.User.EmployeeID ?? 0);

            db.SaveChanges();
            this.Flash("Запись обновлена");
            return RedirectToAction("Index");
        }

        public ActionResult Edit(int id)
        {
            var item = db.ChkpPermits.Find(id);
            if (item == null || !rep.UserCanEdit(AppUser.User, item))
            {
                return HttpNotFound();
            }

            ViewBag.SubjectID = new SelectList(db.ChkpPermitSubjects.OrderBy(s => s.Title), "ID", "Title");
            return item.StartReg.HasValue ? View("EditLocked", item) : View(item);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ID,Type,SubjectID,Start,End,Comment")] Permit model)
        {
            var item = db.ChkpPermits.Find(model.ID);
            if (item == null || !rep.UserCanEdit(AppUser.User, item))
            {
                return HttpNotFound();
            }

            if (ModelState.IsValid)
            {                                
                if (item.StartReg == null)
                {
                    item.Type = model.Type;
                    item.SubjectID = model.SubjectID;
                    item.Start = model.Start;                    
                }

                item.End = model.End;
                item.Comment = model.Comment;

                rep.LogChange(item, "Редактирование согласования", AppUser.Login, AppUser.User.EmployeeID ?? 0);
                db.SaveChanges();
                this.Flash("Запись обновлена");
                return RedirectToAction("Index");
            }

            ViewBag.AuthorID = new SelectList(db.Users, "ID", "Login", model.AuthorID);
            ViewBag.DepartmentID = new SelectList(db.Departments, "DepartmentID", "Title", model.DepartmentID);
            ViewBag.EmployeeID = new SelectList(db.Employees, "ID", "LastName", model.EmployeeID);
            ViewBag.SubjectID = new SelectList(db.ChkpPermitSubjects, "ID", "Title", model.SubjectID);

            return item.StartReg.HasValue ? View("EditLocked", item) : View(item);
        }

        public ActionResult Delete(int id)
        {
            var item = db.ChkpPermits.Find(id);
            if (item == null || !rep.UserCanDelete(AppUser.User, item))
            {
                return HttpNotFound();
            }
            item.IsDeleted = true;
            rep.LogChange(item, "Удаление записи", AppUser.User.Login, AppUser.User.EmployeeID ?? 0);
            db.SaveChanges();
            this.Flash("Запись удалена");
            return RedirectToAction("Index");
        }
    }
}
