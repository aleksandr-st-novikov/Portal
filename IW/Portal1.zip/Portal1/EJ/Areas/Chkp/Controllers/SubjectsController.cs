﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using EJ.DAL;
using EJ.DAL.Models;
using EJ.DAL.Chkp.Models;

namespace EJ.Areas.Chkp.Controllers
{
    public class SubjectsController : ChkpBaseController
    {
        public ActionResult Index()
        {
            return View(db.ChkpPermitSubjects.OrderBy(s => s.Title).ToList());
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Title,IsActive")] PermitSubject model)
        {
            if (ModelState.IsValid)
            {
                db.ChkpPermitSubjects.Add(model);
                db.SaveChanges();
                this.Flash("Запись успешно добавлена");
                return RedirectToAction("Index");
            }

            return View(model);
        }

        public ActionResult Edit(int id)
        {
            PermitSubject ejSkedSubject = db.ChkpPermitSubjects.Find(id);
            if (ejSkedSubject == null)
            {
                return HttpNotFound();
            }
            return View(ejSkedSubject);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ID,Title,IsActive")] PermitSubject ejSkedSubject)
        {
            if (ModelState.IsValid)
            {
                db.Entry(ejSkedSubject).State = EntityState.Modified;
                db.SaveChanges();
                this.Flash("Запись сохранена");
                return RedirectToAction("Index");
            }
            return View(ejSkedSubject);
        }

        public ActionResult Delete(int id)
        {
            var item = db.ChkpPermitSubjects.Find(id);
            if (item == null)
            {
                return HttpNotFound();
            }
            db.ChkpPermitSubjects.Remove(item);
            db.SaveChanges();
            this.Flash("Запись удалена");
            return RedirectToAction("Index");
        }
    }
}
