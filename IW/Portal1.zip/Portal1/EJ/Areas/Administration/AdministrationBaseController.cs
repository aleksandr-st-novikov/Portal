﻿using System.Web.Mvc;

namespace EJ.Areas.Administration
{
    //[Authorize(Roles = "Отдел информационных технологий")]
    public abstract class AdministrationBaseController : BaseController { }
}