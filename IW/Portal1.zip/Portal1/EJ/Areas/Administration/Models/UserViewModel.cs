﻿using EJ.DAL;
using EJ.DAL.Models;
using EJ.DAL.Models.Rbac;
using System.Collections.Generic;
using System.Web.Mvc;
using System.Linq;

namespace EJ.Areas.Administration.Models
{
    public class UserViewModel
    {
        public User User { get; set; }        
        public SelectList EmployeesSelect { get; set; }
        public List<Role> Roles { get; set; }
        public HashSet<int> AssignedRoles { get; set; }

        public UserViewModel()
        {
            User = new User();
            AssignedRoles = new HashSet<int>();
        }

        public void Init(EJContext db)
        {
            Roles = db.RbacRoles.OrderBy(r => r.Name).ToList();
            EmployeesSelect = new SelectList(db.Employees.OrderBy(e => e.LastName), "ID", "FullName", User.EmployeeID);
            AssignedRoles = User.Roles != null ? new HashSet<int>(User.Roles.Select(r => r.RoleID)) : new HashSet<int>();
        }
    }
}