﻿using EJ.DAL;
using EJ.DAL.Models.Rbac;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace EJ.Areas.Administration.Models
{
    public class OperationsGroupViewModel
    {
        public string Name { get; set; }
        public ICollection<Operation> Operations { get; set; }

        public static List<OperationsGroupViewModel> CreateList(EJContext db)
        {
            return db.RbacOperations
                .GroupBy(p => p.Area)
                .OrderBy(g => g.Key)
                .ToList()
                .Select(g => new OperationsGroupViewModel() { Name = g.Key, Operations = new List<Operation>(g) })
                .ToList();
        }
    }

    public class RoleViewModel
    {
        public int RoleID { get; set; }
        [Required, StringLength(100), Display(Name = "Название")]
        public string Name { get; set; }

        public ICollection<OperationsGroupViewModel> OperationsGroups { get; set; }
        public HashSet<int> AssignedOperations { get; set; }
    }
}