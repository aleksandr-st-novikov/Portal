﻿using EJ.Areas.Administration.Models;
using EJ.DAL.Models;
using EJ.DAL.Models.Rbac;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web.Mvc;

namespace EJ.Areas.Administration.Controllers
{
    public class UsersController : AdministrationBaseController
    {
        SelectList EmployeesSelect(int? selected = null)
        {
            return new SelectList(db.Employees.OrderBy(e => e.LastName).ThenBy(e => e.FirstName), "ID", "FullName", selected);
        }

        public ActionResult Index()
        {
            var users = db.Users.Include(u => u.Employee).OrderBy(u => u.Login);
            return View(users.ToList());
        }
        
        public ActionResult Create()
        {
            var model = new UserViewModel();
            model.Init(db);
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "User,AssignedRoles")] UserViewModel model)
        {
            if (ModelState.IsValid)
            {
                var user = model.User;
                user.Registered = DateTime.Now;
                user.Roles = new List<Role>(model.AssignedRoles.Count);
                foreach (int rid in model.AssignedRoles)
                {
                    var role = new Role() { RoleID = rid };
                    db.RbacRoles.Attach(role);
                    user.Roles.Add(role);
                }
                db.Users.Add(user);
                db.SaveChanges();
                this.Flash("Пользователь успешно добавлен", FlashClass.Success);
                return RedirectToAction("Index");
            }

            model.Init(db);
            return View(model);
        }

        public ActionResult Edit(int id)
        {
            var user = db.Users.Find(id);
            if (user == null)
            {
                return HttpNotFound();
            }
            var model = new UserViewModel() { User = user };
            model.Init(db);
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "User,AssignedRoles")] UserViewModel model)
        {
            if (ModelState.IsValid)
            {
                var user = db.Users.Find(model.User.ID);
                if (user == null)
                {
                    return HttpNotFound();
                }

                user.Login = model.User.Login;
                user.EmployeeID = model.User.EmployeeID;
                user.IsActive = model.User.IsActive;
                db.Entry(user).State = EntityState.Modified;
                user.Roles.Clear();
                db.SaveChanges();

                foreach (int rid in model.AssignedRoles)
                {
                    user.Roles.Add(db.RbacRoles.Find(rid));
                }
                db.SaveChanges();

                this.Flash("Пользователь сохранен", FlashClass.Success);
                return RedirectToAction("Index");
            }
            model.Init(db);
            return View(model);
        }

        public ActionResult Delete(int id)
        {
            var user = db.Users.Find(id);
            if (user == null)
            {
                return HttpNotFound();
            }
            db.Users.Remove(user);
            db.SaveChanges();
            this.Flash("Пользователь удален", FlashClass.Success);
            return RedirectToAction("Index");
        }
    }
}
