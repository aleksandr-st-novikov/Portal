﻿using EJ.Areas.Administration.Models;
using EJ.DAL.Models.Rbac;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web.Mvc;

namespace EJ.Areas.Administration.Controllers
{
    public class RolesController : AdministrationBaseController
    {
        public ActionResult Index()
        {
            return View(db.RbacRoles.OrderBy(r => r.Name).ToList());
        }

        public ActionResult Create()
        {
            var model = new RoleViewModel()
            {
                AssignedOperations = new HashSet<int>(),
                OperationsGroups = OperationsGroupViewModel.CreateList(db)
            };
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Name,AssignedOperations")] RoleViewModel model)
        {
            if (ModelState.IsValid)
            {
                var role = new Role() { Name = model.Name, Operations = new List<Operation>() };
                foreach (int pid in model.AssignedOperations)
                {
                    role.Operations.Add(db.RbacOperations.Find(pid));
                }
                db.RbacRoles.Add(role);
                db.SaveChanges();
                this.Flash("Роль добавлена");
                return RedirectToAction("Index");
            }

            model.OperationsGroups = OperationsGroupViewModel.CreateList(db);
            return View(model);
        }

        public ActionResult Edit(int id)
        {
            var role = db.RbacRoles.Find(id);
            if (role == null)
            {
                return HttpNotFound();
            }
            var model = new RoleViewModel()
            {
                Name = role.Name,
                RoleID = role.RoleID,
                OperationsGroups = OperationsGroupViewModel.CreateList(db),
                AssignedOperations = new HashSet<int>(role.Operations.Select(p => p.OperationID))
            };
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "RoleID,Name,AssignedOperations")] RoleViewModel model)
        {
            if (ModelState.IsValid)
            {
                var item = db.RbacRoles.Find(model.RoleID);
                if (item == null)
                {
                    return HttpNotFound();
                }

                item.Name = model.Name;
                item.Operations.Clear();
                db.Entry(item).State = EntityState.Modified;
                db.SaveChanges();

                foreach (int id in model.AssignedOperations)
                {
                    item.Operations.Add(db.RbacOperations.Find(id));
                }
                db.SaveChanges();

                this.Flash("Роль сохранена");
                return RedirectToAction("Index");
            }
            model.OperationsGroups = OperationsGroupViewModel.CreateList(db);
            return View(model);
        }

        public ActionResult Delete(int id)
        {
            var item = db.RbacRoles.Find(id);
            db.RbacRoles.Remove(item);
            db.SaveChanges();
            this.Flash("Роль удалена");
            return RedirectToAction("Index");
        }
    }
}
