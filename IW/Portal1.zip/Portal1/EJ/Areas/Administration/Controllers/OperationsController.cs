﻿using EJ.Areas.Administration.Models;
using EJ.DAL.Models.Rbac;
using System.Data.Entity;
using System.Web.Mvc;

namespace EJ.Areas.Administration.Controllers
{
    public class OperationsController : AdministrationBaseController
    {
        public ActionResult Index()
        {
            return View(OperationsGroupViewModel.CreateList(db));
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Area,Name,Description")] Operation model)
        {
            if (ModelState.IsValid)
            {
                db.RbacOperations.Add(model);
                db.SaveChanges();
                this.Flash("Операция добавлена");
                return RedirectToAction("Index");
            }

            return View(model);
        }

        public ActionResult Edit(int id)
        {
            Operation item = db.RbacOperations.Find(id);
            if (item == null)
            {
                return HttpNotFound();
            }
            return View(item);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "OperationID,Area,Name,Description")] Operation model)
        {
            if (ModelState.IsValid)
            {
                db.Entry(model).State = EntityState.Modified;
                db.SaveChanges();
                this.Flash("Операция изменена");
                return RedirectToAction("Index");
            }
            return View(model);
        }

        public ActionResult Delete(int id)
        {
            var item = db.RbacOperations.Find(id);
            db.RbacOperations.Remove(item);
            db.SaveChanges();
            this.Flash("Операция удалена");
            return RedirectToAction("Index");
        }
    }
}
