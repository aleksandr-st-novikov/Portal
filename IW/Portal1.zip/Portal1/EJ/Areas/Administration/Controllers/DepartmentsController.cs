﻿using EJ.DAL;
using EJ.DAL.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EJ.Areas.Administration.Controllers
{
    public class DepartmentsController : AdministrationBaseController
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult List()
        {
            var data = db.Departments.OrderBy(d => d.Title).Select(d => new { Title = d.Title, Id = d.DepartmentID, Parent = d.ParentID, Head = d.Head != null ? d.Head.LastName + " " + d.Head.FirstName : "" }).ToList();
            return Json(data, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public ActionResult Edit(int id = 0)
        {
            var dep = db.Departments.Find(id);
            if (dep == null)
            {
                return HttpNotFound();
            }
            ViewBag.ParentID = DropDownListHelpers.DepartmentList(db.Departments.OrderBy(d => d.Title).ToList(), dep.ParentID, null);
            return View(dep);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "DepartmentID,Title,ParentID")] Department model)
        {
            if (ModelState.IsValid)
            {
                var dep = db.Departments.Find(model.DepartmentID);
                if (dep == null)
                {
                    return HttpNotFound();
                }

                if (model.ParentID == model.DepartmentID)
                {
                    ModelState.AddModelError("ParentID", "Родительское подразделение указано неверно");
                    model.Head = db.Employees.Find(dep.HeadID);
                }
                else
                {
                    dep.Title = model.Title;
                    dep.ParentID = model.ParentID;
                    db.SaveChanges();
                    return Json(new { result = "ok" });
                }
            }
            ViewBag.ParentID = DropDownListHelpers.DepartmentList(db.Departments.OrderBy(d => d.Title).ToList(), model.ParentID, null);
            return View(model);
        }
    }
}